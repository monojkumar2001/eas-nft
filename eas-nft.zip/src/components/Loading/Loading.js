import React from 'react'
import "../../Style/Loading.css"
const Loading = () => {
  return (
<div className="load-wrapper">
<div class="loader"></div>
</div>
  )
}

export default Loading